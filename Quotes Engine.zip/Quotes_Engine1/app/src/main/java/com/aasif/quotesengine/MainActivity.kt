package com.aasif.quotesengine

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installSplashScreen()
        setContentView(R.layout.activity_main)
       /* val quoteList = findViewById<RecyclerView>(R.id.quoteList)
        quoteList.layoutManager = LinearLayoutManager(this)
        quoteList.adapter = QuotesAdapter(getQuotes(), this)*/
    }

    private fun getQuotes(): List<String>? {
        val quotes: MutableList<String> = ArrayList()
        var bufferedReader: BufferedReader? = null
        try {
            bufferedReader =
                BufferedReader(InputStreamReader(this.assets.open("quotes.txt"), "UTF-8"))
            var line: String
            while (bufferedReader.readLine().also { line = it } != null) {
                quotes.add(line)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }
        return quotes
    }
}